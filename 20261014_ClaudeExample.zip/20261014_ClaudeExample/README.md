RATIONALE

On 2026-10-13 attended virtually a session of the [CFO Connect Summit](https://www.spendesk.com/events/cfo-connect-summit/).

The concept of the sessions was to see what tools are available within finance (including financial controlling, CFO and related roles, etc): and of course AI was a constant presence all across.

One of the sessions was a presentation from Nicholas Boucher on "Building an AI Finance Workflow Step by Step".

Usually, in these sessions, all the material provided is explicitly stated "not for distribution".

In this case, while presenting, Nicholas instead urged the audience to take screenshots and share within the finance community.

I did a step further: while he was talking, actually opened a sessions with Claude (Pro subscription, just for this month), and provided the prompts as screenshots.

Anyway, as the Claude Pro subscription *does* *not* provide the data confidentiality and privacy level required, and the first prompt of course quoted access to data, asked also Claude to generate synthetic data.

This ZIP file has been created to support the article ([Organizational Support 20: AI-augmented Financial Controlling - concepts and example](https://robertolofaro.com/index.php?page=683))

You will find the following files:
| Directory | Filename | File contents |
| --- | --- | --- |
| / | README.md | This file |
| / | 20261013_prompts_bouchard.md | The prompts transcribed as text |
| / | 01_analysis.webp | The prompt asking to generate the dashaboard |
| / | 02_audit.png | The prompt asking to carry out an analysis on what was produced by 01_analysis.webp |
| / | 03_skills.png | The prompt to transform the activity into a repeatable skill |
| /step00_syntheticdata/ | AquaPure_DataPack_Sep2026.zip | The data that asked Claude to generate as "source" |
| /step01_analysis/ | AquaPure September Close.html | The interactive dashboard !
| /step01_analysis/ | AquaPure_Sep2026_Board_Close.xlsx | An Acrobat version of the dashboard and data input |
| /step02_audit-analysis/ | AquaPure_Dashboard_Audit.docx |

I did not share the actual prompt and their structure, but within the article is described how usually, to enable recycling and easy documentation and "audit trail", store requests & replies.



