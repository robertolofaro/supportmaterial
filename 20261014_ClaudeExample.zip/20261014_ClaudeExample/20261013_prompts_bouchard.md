
PHASE 1: Analysis

I am the CFO of AquaPure Beverages, a drinks company. I'm presenting the September 2026 close to the board.
All the data in my Google driver folder "AquaPure Data Pack - Sep 2026". Use only these files and never invent a number.

Step 1, before building anything: read evey file, tell me which file leads which part of the dashboard, list any numbers that don't tie betweenfiles, and give me the one key message of the month in two sentences: then wait for my OK.

Step 2, build a board dashboard as one self-contained HTML page, with the data embedded an no external links.
Sections: an opening with the key message and one chart that proves it, the month in one page with 6 KPI cards and the decisions I need from the board, profitability with  an EBITDA bridge from budget to actual, cash and working capital, full year 2026 with actuals plus forecast against budget, sales and customers, people, a cash what-if with sliders, and a proof centre
Every section starts with a one-sentence headline that tells the story, not a title.
Show actual vs budget everywhere a budget exists: budget as a dashed line, actuals in one color, forecast in another, and the variance labeled in green or red.

Design: use our cfo dashboard skill.
The proof centre runs checks live in the page: balance sheet balances every momth, cash rolls forward, the trial balance matches the AR and AP agings, the ledger matches the change in the trial balance, and every sales view adds up to the P&L. Show how many checkes pass in the sidebar.

PHASE 2: Audit

I need to document, in a docx file, the audit of the HTML dashboard and the JavaScript code it contains, covering all the figures and graphs used in the cost center analysis.

Can you audit both the HTML structure and the JavaScript code of the dashboard, and document your findings in plain English, one code block after another?

For each figure and graph, show what it displays, how it is produced in the HTML, how it is produced in the JavaScript code, and where the underlying data comes from. The show the results of the analysis and how they trace back to the dashboard and its source data.

The audience does not know HTML or JavaScript, and we need to show that the analysis is correct and can be traced back to its source.

TO MAKE IT REPEATABLE: skill creation

Create a skill that lets me refresh my CFO cockpit HTML dashboard every month: I'll give you the new data export, and the skiill should updated the figures, graphs and period labels while keeping the structure and calculation logic unchanged.


